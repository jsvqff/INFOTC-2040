﻿using System;

namespace MealTime
{
    class Program
    {
        static void Main()
        {
            // Prompt the user to enter the time
            Console.Write("Enter the time (in 24-hour format, e.g., 13:30): ");
            string userInput = Console.ReadLine();

            // Convert the user input to a floating-point value
            float convertedTime = ConvertTime(userInput);

            // Determine the meal time based on the converted time
            string mealTime = GetMealTime(convertedTime);

            // Output the appropriate message to the user
            Console.WriteLine(mealTime);

            // End the program
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        public static float ConvertTime(string time)
        {
            string[] timeParts = time.Split(':');
            if (timeParts.Length == 2 && float.TryParse(timeParts[0], out float hours) && float.TryParse(timeParts[1], out float minutes))
            {
                return hours + (minutes / 60);
            }
            else
            {
                // Invalid input, return -1 to indicate an error
                return -1;
            }
        }

        public static string GetMealTime(float convertedTime)
        {
            if (convertedTime >= 7.0 && convertedTime <= 8.0)
            {
                return "It's Breakfast time!";
            }
            else if (convertedTime >= 12.0 && convertedTime <= 13.0)
            {
                return "It's Lunch time!";
            }
            else if (convertedTime >= 18.0 && convertedTime <= 19.0)
            {
                return "It's Dinner time!";
            }
            else
            {
                return "Not time to eat!";
            }
        }
    }
}
