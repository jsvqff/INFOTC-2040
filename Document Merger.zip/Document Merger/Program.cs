﻿using System;
using System.IO;

namespace DocumentMerger
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Document Merger\n");

            do
            {
                try
                {
                    Console.Write("Enter the name of the first text file: ");
                    string file1Name = Console.ReadLine();

                    if (!File.Exists(file1Name))
                    {
                        Console.WriteLine($"The file '{file1Name}' does not exist. Please try again.");
                        continue;
                    }

                    Console.Write("Enter the name of the second text file: ");
                    string file2Name = Console.ReadLine();

                    if (!File.Exists(file2Name))
                    {
                        Console.WriteLine($"The file '{file2Name}' does not exist. Please try again.");
                        continue;
                    }

                    Console.Write("Enter new filename (default: " + Path.GetFileNameWithoutExtension(file1Name) + Path.GetFileNameWithoutExtension(file2Name) + ".txt): ");
                    string outputFileName = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(outputFileName))
                    {
                        outputFileName = Path.GetFileNameWithoutExtension(file1Name) + Path.GetFileNameWithoutExtension(file2Name) + ".txt";
                    }
                    else if (!outputFileName.EndsWith(".txt"))
                    {
                        outputFileName += ".txt";
                    }

                    string file1Content = File.ReadAllText(file1Name);
                    string file2Content = File.ReadAllText(file2Name);
                    string mergedContent = file1Content + file2Content;

                    File.WriteAllText(outputFileName, mergedContent);

                    Console.WriteLine($"{outputFileName} was successfully saved. The document contains {mergedContent.Length} characters.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex.Message}");
                }

                Console.Write("Do you want to merge two more files? (yes/no): ");
            } while (Console.ReadLine().ToLower() == "yes");
        }
    }
}
