namespace AutoDemo{
    enum AutoType{
        Sedan,
        Truck,
        Van,
        SUV
    }
}