﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

enum AccountType
{
    Savings,
    Checking
}

class BankAccount
{
    public string AccountNumber { get; set; }
    public int PIN { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public decimal Balance { get; set; }
    public int NumDeposits { get; set; }
    public int NumWithdrawals { get; set; }
    public AccountType AccountType { get; set; }
}

class Program
{
    private static List<BankAccount> accounts;
    private static BankAccount currentUser;

    static void Main(string[] args)
    {
        LoadAccounts();

        while (true)
        {
            Console.WriteLine("Welcome to your Online Banking Application!\n");
            Console.WriteLine("1. Account Login\n2. Create Account\n3. Administrator Login\n4. Quit\n");
            Console.Write("Select Option: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AccountLogin();
                    break;
                case "2":
                    CreateAccount();
                    break;
                case "3":
                    AdministratorLogin();
                    break;
                case "4":
                    SaveAccounts();
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.\n");
                    break;
            }
        }
    }

    private static void AccountLogin()
    {
        Console.WriteLine("--------------------\nACCOUNT LOGIN\n--------------------\n");

        string accountNumber;
        do
        {
            Console.Write("Enter your account number: ");
            accountNumber = Console.ReadLine();

            if (string.IsNullOrEmpty(accountNumber))
                Console.WriteLine("ERROR. You must enter an account number.\n");

        } while (string.IsNullOrEmpty(accountNumber));

        Console.Write("Enter your PIN: ");
        int pin = int.Parse(Console.ReadLine());

        currentUser = accounts.FirstOrDefault(account => account.AccountNumber == accountNumber && account.PIN == pin);

        if (currentUser != null)
        {
            Console.WriteLine($"Welcome back {currentUser.FirstName} {currentUser.LastName}! How can we help you today?\n");
            AccountServices();
        }
        else
        {
            Console.WriteLine("Invalid account number or PIN. Please try again.\n");
        }
    }

    private static void CreateAccount()
    {
        Console.WriteLine("----------------------------\nCREATE ACCOUNT\n----------------------------\n");

        BankAccount newAccount = new BankAccount();

        Console.Write("Enter your first name: ");
        newAccount.FirstName = Console.ReadLine();

        Console.Write("\nEnter your last name: ");
        newAccount.LastName = Console.ReadLine();

        do
        {
            Console.Write("\nSelect a PIN. Must be 4 digits: ");
            newAccount.PIN = int.Parse(Console.ReadLine());

            if (newAccount.PIN < 1000 || newAccount.PIN > 9999)
                Console.WriteLine("Invalid PIN. Must be 4 digits.\n");

        } while (newAccount.PIN < 1000 || newAccount.PIN > 9999);

        Console.WriteLine("\nWhat type of account do you want to open?");
        Console.WriteLine("1. Savings\n2. Checking\n");

        do
        {
            Console.Write("Select Option: ");
            int accountTypeChoice = int.Parse(Console.ReadLine());

            if (accountTypeChoice == 1)
            {
                newAccount.AccountType = AccountType.Savings;
                break;
            }
            else if (accountTypeChoice == 2)
            {
                newAccount.AccountType = AccountType.Checking;
                break;
            }
            else
            {
                Console.WriteLine("Invalid choice. Please try again.\n");
            }

        } while (true);

        newAccount.Balance = 100;
        newAccount.NumDeposits = 1;
        newAccount.NumWithdrawals = 0;
        newAccount.AccountNumber = GenerateAccountNumber();

        accounts.Add(newAccount);

        Console.WriteLine($"\nCongratulations {newAccount.FirstName} {newAccount.LastName}! Your account is open with an initial deposit of $100. Your account number is: {newAccount.AccountNumber}. You can log in to access account services now.\n");

        SaveAccounts();
    }

    private static void AccountServices()
    {
        while (true)
        {
            Console.WriteLine("What would you like to do?\n");
            Console.WriteLine("1. Make a withdrawal\n2. Make a deposit\n3. Transfer funds to another user account\n4. Balance Inquiry\n5. Back to Main Menu\n");
            Console.Write("Select Option: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    MakeWithdrawal();
                    break;
                case "2":
                    MakeDeposit();
                    break;
                case "3":
                    TransferFunds();
                    break;
                case "4":
                    BalanceInquiry();
                    break;
                case "5":
                    SaveAccounts();
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.\n");
                    break;
            }
        }
    }

    private static void MakeWithdrawal()
    {
        Console.WriteLine("\nHow much would you like to withdraw?");
        decimal withdrawalAmount = decimal.Parse(Console.ReadLine());

        if (withdrawalAmount > currentUser.Balance)
        {
            Console.WriteLine($"Withdraw failed. Insufficient funds. Current balance: ${currentUser.Balance}\n");
        }
        else
        {
            currentUser.Balance -= withdrawalAmount;
            currentUser.NumWithdrawals++;
            Console.WriteLine($"Withdrawal successful. New balance: ${currentUser.Balance}\n");
        }
    }

    private static void MakeDeposit()
    {
        Console.WriteLine("\nHow much would you like to deposit?");
        decimal depositAmount = decimal.Parse(Console.ReadLine());

        currentUser.Balance += depositAmount;
        currentUser.NumDeposits++;
        Console.WriteLine($"Deposit successful. New balance: ${currentUser.Balance}\n");
    }

    private static void TransferFunds()
    {
        Console.WriteLine("\nHow much would you like to transfer?");
        decimal transferAmount = decimal.Parse(Console.ReadLine());

        Console.Write("Enter Account Number of the person to transfer to: ");
        string targetAccountNumber = Console.ReadLine();

        BankAccount targetAccount = accounts.FirstOrDefault(account => account.AccountNumber == targetAccountNumber);

        if (targetAccount == null || transferAmount > currentUser.Balance)
        {
            Console.WriteLine("Transfer Failed: Either Insufficient Funds or Account Number is incorrect!\n");
        }
        else
        {
            currentUser.Balance -= transferAmount;
            currentUser.NumWithdrawals++;
            targetAccount.Balance += transferAmount;
            targetAccount.NumDeposits++;

            Console.WriteLine($"Transfer successful. New balance: ${currentUser.Balance}\n");
        }
    }

    private static void BalanceInquiry()
    {
        Console.WriteLine($"\nCurrent Balance: ${currentUser.Balance}\n");
    }

    private static void AdministratorLogin()
    {
        Console.WriteLine("-----------------------\nADMIN LOGIN\n-----------------------\n");

        Console.Write("Enter admin name: ");
        string adminName = Console.ReadLine();

        Console.Write("Enter password: ");
        string password = Console.ReadLine();

        if (adminName == "admin1" && password == "24680" || adminName == "admin2" && password == "13579")
        {
            AdministratorMenu();
        }
        else
        {
            Console.WriteLine("Invalid username/password combination\n");
        }
    }

    private static void LoadAccounts()
    {
        accounts = File.ReadAllLines("account_data.csv")
                       .Skip(1)
                       .Select(line =>
                       {
                           var values = line.Split(',');
                           return new BankAccount
                           {
                               AccountNumber = values[0],
                               PIN = int.Parse(values[1]),
                               FirstName = values[2],
                               LastName = values[3],
                               Balance = decimal.Parse(values[4]),
                               NumDeposits = int.Parse(values[5]),
                               NumWithdrawals = int.Parse(values[6]),
                               AccountType = (AccountType)Enum.Parse(typeof(AccountType), values[7], true)
                           };
                       })
                       .ToList();
    }

    private static void SaveAccounts()
    {
        var lines = new List<string> { "account_number,PIN,first_name,last_name,balance,num_deposits,num_withdrawals,account_type" };
        lines.AddRange(accounts.Select(account =>
            $"{account.AccountNumber},{account.PIN},{account.FirstName},{account.LastName},{account.Balance},{account.NumDeposits},{account.NumWithdrawals},{account.AccountType}"));
        File.WriteAllLines("account_data.csv", lines);
    }

    private static string GenerateAccountNumber()
    {
        Random random = new Random();
        string accountNumber = "183977" + random.Next(1000000000, int.MaxValue).ToString("D10");
        return accountNumber;
    }

    private static void AdministratorMenu()
    {
        while (true)
        {
            Console.WriteLine("\nSelect Option: ");
            Console.WriteLine("1. Average Savings Account Balance");
            Console.WriteLine("2. Total Savings Account Balance");
            Console.WriteLine("3. Average Checking Account Balance");
            Console.WriteLine("4. Total Checking Account Balance");
            Console.WriteLine("5. Total Number of Accounts");
            Console.WriteLine("6. Total 10 Deposit Accounts");
            Console.WriteLine("7. Total 10 Withdrawal Accounts");
            Console.WriteLine("8. Back to Main Menu\n");

            Console.Write("Select Option: ");
            string adminChoice = Console.ReadLine();

            switch (adminChoice)
            {
                case "1":
                    CalculateAndDisplayAverageBalance(AccountType.Savings);
                    break;
                case "2":
                    CalculateAndDisplayTotalBalance(AccountType.Savings);
                    break;
                case "3":
                    CalculateAndDisplayAverageBalance(AccountType.Checking);
                    break;
                case "4":
                    CalculateAndDisplayTotalBalance(AccountType.Checking);
                    break;
                case "5":
                    DisplayTotalNumberOfAccounts();
                    break;
                case "6":
                    DisplayTop10Depositors();
                    break;
                case "7":
                    DisplayTop10Withdrawers();
                    break;
                case "8":
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.\n");
                    break;
            }
        }
    }

    private static void CalculateAndDisplayAverageBalance(AccountType accountType)
    {
        var accountsOfType = accounts.Where(account => account.AccountType == accountType);
        decimal averageBalance = accountsOfType.Any() ? accountsOfType.Average(account => account.Balance) : 0;

        Console.WriteLine($"----------------------\nAverage {accountType} Account Balance\n----------------------");
        Console.WriteLine($"Average {accountType} Account Balance: ${averageBalance:F2}\n");
    }

    private static void CalculateAndDisplayTotalBalance(AccountType accountType)
    {
        var accountsOfType = accounts.Where(account => account.AccountType == accountType);
        decimal totalBalance = accountsOfType.Any() ? accountsOfType.Sum(account => account.Balance) : 0;

        Console.WriteLine($"----------------------\nTotal {accountType} Account Balance\n----------------------");
        Console.WriteLine($"Total {accountType} Account Balance: ${totalBalance:F2}\n");
    }

    private static void DisplayTotalNumberOfAccounts()
    {
        int totalSavingsAccounts = accounts.Count(account => account.AccountType == AccountType.Savings);
        int totalCheckingAccounts = accounts.Count(account => account.AccountType == AccountType.Checking);

        Console.WriteLine("----------------------\nTotal Number of Accounts\n----------------------");
        Console.WriteLine($"Savings Accounts: {totalSavingsAccounts}");
        Console.WriteLine($"Checking Accounts: {totalCheckingAccounts}\n");
    }

    private static void DisplayTop10Depositors()
    {
        var top10Depositors = accounts.OrderByDescending(account => account.NumDeposits).Take(10);

        Console.WriteLine("----------------------\nTotal 10 Deposit Accounts\n----------------------");
        foreach (var depositor in top10Depositors)
        {
            Console.WriteLine($"{depositor.FirstName} {depositor.LastName}: {depositor.NumDeposits} deposits");
        }
        Console.WriteLine();
    }

    private static void DisplayTop10Withdrawers()
    {
        var top10Withdrawers = accounts.OrderByDescending(account => account.NumWithdrawals).Take(10);

        Console.WriteLine("----------------------\nTotal 10 Withdrawal Accounts\n----------------------");
        foreach (var withdrawer in top10Withdrawers)
        {
            Console.WriteLine($"{withdrawer.FirstName} {withdrawer.LastName}: {withdrawer.NumWithdrawals} withdrawals");
        }
        Console.WriteLine();
    }

}
