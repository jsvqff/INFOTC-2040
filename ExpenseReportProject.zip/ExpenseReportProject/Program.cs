﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ExpenseReport
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> categories = new List<string>();
            List<double> costs = new List<double>();

            ReadExpenseData("credit_card.csv", categories, costs);

            Console.WriteLine("*****************");
            Console.WriteLine("Expense Report");
            Console.WriteLine("*****************\n");

            double totalCost = CalculateTotalCost(costs);
            int numberOfPurchases = costs.Count;
            double averagePurchase = totalCost / numberOfPurchases;

            Console.WriteLine($"Total Cost of Purchases: ${totalCost:F2}");
            Console.WriteLine($"Number of Purchases: {numberOfPurchases}");
            Console.WriteLine($"Average Purchase: ${averagePurchase:F2}\n");

            DisplayCostByCategory(categories, costs);
            DisplayNumberOfPurchasesByCategory(categories);
            DisplayMostExpensivePurchase(categories, costs);
            DisplayLeastExpensivePurchase(categories, costs);
        }

        static void ReadExpenseData(string fileName, List<string> categories, List<double> costs)
        {
            try
            {
                string[] lines = File.ReadAllLines(fileName);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(' ');
                    if (parts.Length != 2)
                    {
                        Console.WriteLine($"Invalid data format: {line}");
                        continue;
                    }

                    string category = parts[0];
                    if (!double.TryParse(parts[1], out double cost))
                    {
                        Console.WriteLine($"Invalid cost value: {line}");
                        continue;
                    }

                    categories.Add(category);
                    costs.Add(cost);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while reading the file: {ex.Message}");
            }
        }

        static double CalculateTotalCost(List<double> costs)
        {
            return costs.Sum();
        }

        static void DisplayCostByCategory(List<string> categories, List<double> costs)
        {
            var groupedExpenses = categories.Zip(costs, (cat, cost) => new { Category = cat, Cost = cost })
                .GroupBy(x => x.Category)
                .Select(g => new { Category = g.Key, TotalCost = g.Sum(x => x.Cost) });

            Console.WriteLine("Cost of Purchases by Category");
            Console.WriteLine("-------------------------");

            foreach (var group in groupedExpenses)
            {
                Console.WriteLine($"{group.Category}: ${group.TotalCost:F2}");
            }
            Console.WriteLine(" ");
        }

        static void DisplayNumberOfPurchasesByCategory(List<string> categories)
        {
            var groupedCategories = categories.GroupBy(cat => cat)
                .Select(g => new { Category = g.Key, Count = g.Count() });

            Console.WriteLine("Number of Purchases by Category");
            Console.WriteLine("-------------------------");

            foreach (var group in groupedCategories)
            {
                Console.WriteLine($"{group.Category} Purchases: {group.Count}");
            }
            Console.WriteLine(" ");
        }

        static void DisplayMostExpensivePurchase(List<string> categories, List<double> costs)
        {
            double maxCost = costs.Max();
            var mostExpensive = categories.Zip(costs, (cat, cost) => new { Category = cat, Cost = cost })
                .Where(item => item.Cost == maxCost)
                .Select(item => new { Category = item.Category, Cost = item.Cost });

            Console.WriteLine("Most Expensive purchase");
            Console.WriteLine("-------------------------");

            foreach (var item in mostExpensive)
            {
                Console.WriteLine($"{item.Category}: ${item.Cost:F2}");
            }
            Console.WriteLine(" ");
        }

        static void DisplayLeastExpensivePurchase(List<string> categories, List<double> costs)
        {
            double minCost = costs.Min();
            var leastExpensive = categories.Zip(costs, (cat, cost) => new { Category = cat, Cost = cost })
                .Where(item => item.Cost == minCost)
                .Select(item => new { Category = item.Category, Cost = item.Cost });

            Console.WriteLine("Least Expensive purchase");
            Console.WriteLine("-------------------------");

            foreach (var item in leastExpensive)
            {
                Console.WriteLine($"{item.Category}: ${item.Cost:F2}");
            }
        }
    }
}

//https://www.w3schools.com/cs/index.php