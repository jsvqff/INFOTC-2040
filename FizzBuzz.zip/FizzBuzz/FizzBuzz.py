
count = 0
for i in range(100):  # Adjust the range to start from 1 instead of 0
    count += 1
    if count % 3 == 0 and count % 5 == 0:
        print("FizzBuzz")
    elif count % 3 == 0:
        print("Fizz")
    elif count % 5 == 0:
        print("Buzz")
    else:
        print(count)    
        