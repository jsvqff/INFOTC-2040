namespace MidtermProject{
    enum EmployeeType{
        Associate,
        Manager,
        Production
    }

    enum SalesLevel{
        Platinum,
        Diamond,
        Gold,
        Silver,
        Bronze
    }
}